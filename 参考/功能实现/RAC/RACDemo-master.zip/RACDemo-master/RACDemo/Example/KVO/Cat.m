//
//  Cat.m
//  RACDemo
//
//  Created by BloodLine on 16/3/20.
//  Copyright © 2016年 BloodLine. All rights reserved.
//

#import "Cat.h"

@implementation Cat

- (instancetype)init {
    self = [super init];
    if (self) {
        self.age = 0;
    }
    return self;
}

@end
