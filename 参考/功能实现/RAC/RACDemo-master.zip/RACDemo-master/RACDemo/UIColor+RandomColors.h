//
//  UIColor+RandomColors.h
//  SCPageViewController
//
//  Created by Stefan Ceriu on 15/02/2014.
//  Copyright (c) 2014 Stefan Ceriu. All rights reserved.
//

@import UIKit;

@interface UIColor (RandomColors)

+ (UIColor *)randomColor;

@end
