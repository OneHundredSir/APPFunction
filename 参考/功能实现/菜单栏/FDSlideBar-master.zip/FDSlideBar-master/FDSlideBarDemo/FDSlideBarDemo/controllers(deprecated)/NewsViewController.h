//
//  ImportantNewsViewController.h
//  FDSlideBarDemo
//
//  Created by fergusding on 15/7/1.
//  Copyright (c) 2015年 fergusding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController

@property (copy, nonatomic) NSString *labelText;

@end
